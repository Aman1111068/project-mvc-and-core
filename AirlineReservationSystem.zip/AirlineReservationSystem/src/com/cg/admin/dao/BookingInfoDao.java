package com.cg.admin.dao;


import java.util.ArrayList;
import java.util.List;




import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;

public interface BookingInfoDao 
{

	 int countBookingIds(int fno)throws AdminException;
	 List<BookingInformation> getAllBookings(int flightNo) throws AdminException;
	 int addNewBookingInformation(BookingInformation bookInfo) throws BookingException;
	BookingInformation getBookingInformation(int bookingId) throws BookingException;
	boolean deleteBookingInformation(int id) throws BookingException;
	ArrayList<FlightInformation> searchFlightInformation(String src, String destination) throws BookingException;
	FlightInformation getParticularFlight(int fno) throws BookingException;
	boolean updateFlightSeatsCNF(FlightInformation f) throws BookingException;

}
