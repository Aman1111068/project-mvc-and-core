package com.cg.admin.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.admin.dao.UsersDao;
import com.cg.admin.dao.UsersDaoImpl;
import com.cg.admin.dto.Users;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.UserException;

public class TestCasesUsers 
{
	static UsersDao usersdao=null;
	static Users users=null;
	
	@BeforeClass
	public static void beforeClass() throws UserException
	{
		usersdao=new UsersDaoImpl();
		users=new Users("Abwadhwa", "Surajmal@15", "Executive" , 9711443344l);
	}
	
	@Test
    public void testAddApplicant1() throws UserException
    {
        Assert.assertEquals(1,usersdao.insertUser(users));
    }
	
	@Test
	public void testParticularUser() throws UserException
	{
		Assert.assertEquals(true, usersdao.fetchParticularUser("Abwadhwa", "Surajmal@15"));
	}
	
	@Test
	public void testFetchRole() throws UserException
	{
		Assert.assertEquals(2, usersdao.fetchRole("Abwadhwa", "Surajmal@15"));
	}

}
